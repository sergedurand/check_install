### WARNING

This code is a stripped down version of the quickzono code:
https://github.com/stanleybak/quickzonoreach

It is used to compute the vertices and plot zonotopes.

All credits to its author.

Only use it internally until the license is figured out.